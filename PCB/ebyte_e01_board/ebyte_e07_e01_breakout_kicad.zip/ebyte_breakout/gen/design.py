"""Shared design data for the E07 + E01 combo breakout.

All coordinates in mm, board origin top-left, +y down.
Modules are placed rotated 180 deg so their signal pad rows face the header.
"""

BOARD_W = 40.5
BOARD_H = 50.0

HDR_Y = 46.5
HDR_X0 = 3.5
HDR_PITCH = 2.54

# Header pin order: (pin, net, tag)
HEADER = [
    (1,  "GND",   "AB"),
    (2,  "MOSI",  "AB"),
    (3,  "SCK",   "AB"),
    (4,  "GDO2",  "A"),
    (5,  "GDO0",  "A"),
    (6,  "CSN_A", "A"),
    (7,  "TX_EN", "A"),
    (8,  "RX_EN", "A"),
    (9,  "VCC",   "AB"),
    (10, "CE",    "B"),
    (11, "CSN_B", "B"),
    (12, "MISO",  "AB"),
    (13, "IRQ",   "B"),
    (14, "GND",   "AB"),
]

def hdr_x(pin):
    return HDR_X0 + (pin - 1) * HDR_PITCH

# ---------------- E07-433M20S (module "A") ----------------
# Datasheet: 18.0 x 32.0 mm, 1.27 mm stamp holes. Signal pads 1..12 along one
# short edge (pin 12 is 2.01 mm from the module edge in bottom view). Opposite
# edge: 13 ANT (long pad 5.00 from edge in bottom view), 14 GND (+2.00),
# 15 GND (+4.00), 16 GND (+1.27).
E07_W, E07_H = 18.0, 32.0
E07_X = HDR_X0 + 0.635 - 2.01      # module left edge (pads offset 0.635 from header pins)
E07_Y = 3.0                        # module top edge
E07_PINS = {
    1: "GND", 2: "MOSI", 3: "SCK", 4: "MISO", 5: "GDO2", 6: "GDO0", 7: "CSN_A",
    8: "TX_EN", 9: "RX_EN", 10: "NC", 11: "VCC", 12: "GND",
    13: "ANT", 14: "GND", 15: "GND", 16: "GND",
}

def e07_pad_local(n):
    """Local (x, y) of pad centre relative to module top-left, module rotated 180."""
    if n <= 12:
        return (2.01 + (n - 1) * 1.27, E07_H)          # bottom edge
    top = {13: 18.0 - 5.0, 14: 18.0 - 7.0, 15: 18.0 - 11.0, 16: 18.0 - 12.27}
    return (top[n], 0.0)                               # top edge

# ---------------- E01-2G4M27SX (module "B") ----------------
# Datasheet: 14.5 x 18.0 mm. Pads 1..8 along one short edge at 1.27 mm
# (pin 8 is 2.80 from the edge in bottom view). Pads 9/10 are GND half-holes
# on the long sides, 13.0 mm from the pad-row edge.
E01_W, E01_H = 14.5, 18.0
E01_X = hdr_x(10) + 0.635 - 2.81   # E01 pad 1 (VCC) sits 0.635 right of header pin 10
E01_Y = E07_Y + E07_H - E01_H     # bottom edges aligned
E01_PINS = {
    1: "VCC", 2: "CE", 3: "CSN_B", 4: "SCK", 5: "MOSI", 6: "MISO", 7: "IRQ",
    8: "GND", 9: "GND", 10: "GND",
}

def e01_pad_local(n):
    if n <= 8:
        return (2.81 + (n - 1) * 1.27, E01_H)
    # rotated 180: original top-view pin 9 on left edge -> now right edge
    y = E01_H - 13.0
    return (E01_W, y) if n == 9 else (0.0, y)

# Routing: every module pad gets a via just below it (VIA_Y); all runs are on B.Cu.
# Header order follows pad order, so pad->header runs are non-crossing diagonals.
# Shared SPI lines between the modules run on B.Cu above the via line (under the modules).
VIA_Y = 36.4
BUS_Y = {"MISO": 31.5, "MOSI": 32.5, "SCK": 33.5}
ROUTED_NETS = ["GDO2", "GDO0", "TX_EN", "RX_EN", "CSN_A", "MOSI", "SCK", "MISO",
               "VCC", "CSN_B", "CE", "IRQ"]
TRACK_W = 0.3
VIA_D, VIA_DRILL = 0.5, 0.3
CLEARANCE = 0.2
