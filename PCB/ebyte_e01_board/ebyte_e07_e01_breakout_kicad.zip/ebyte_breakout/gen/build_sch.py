"""Generate the KiCad 7 schematic, symbol library, lib tables and project file."""
import sys, os, uuid, json
sys.path.insert(0, os.path.dirname(__file__))
from design import *

OUTDIR = sys.argv[1]
NAME = "ebyte_e07_e01_breakout"
ROOT = "7b1c6a2e-3d4f-4a5b-9c8d-0e1f2a3b4c5d"

def U(): return str(uuid.uuid4())

# ---------------- symbol definitions ----------------
E07_PIN_TYPE = {1: "power_in", 2: "input", 3: "input", 4: "output", 5: "output", 6: "output",
                7: "input", 8: "input", 9: "input", 10: "no_connect", 11: "power_in", 12: "power_in",
                13: "passive", 14: "power_in", 15: "power_in", 16: "power_in"}
E01_PIN_TYPE = {1: "power_in", 2: "input", 3: "input", 4: "input", 5: "input", 6: "output",
                7: "output", 8: "power_in", 9: "power_in", 10: "power_in"}
E07_NAMES = {1: "GND", 2: "MOSI", 3: "SCK", 4: "MISO/GDO1", 5: "GDO2", 6: "GDO0", 7: "CSN",
             8: "TX_EN", 9: "RX_EN", 10: "NC", 11: "VCC", 12: "GND", 13: "ANT", 14: "GND", 15: "GND", 16: "GND"}
E01_NAMES = {1: "VCC", 2: "CE", 3: "CSN", 4: "SCK", 5: "MOSI", 6: "MISO", 7: "IRQ", 8: "GND", 9: "GND", 10: "GND"}

def pin(num, name, ptype, x, y, angle):
    return (f'      (pin {ptype} line (at {x:.2f} {y:.2f} {angle}) (length 2.54)\n'
            f'        (name "{name}" (effects (font (size 1.27 1.27))))\n'
            f'        (number "{num}" (effects (font (size 1.27 1.27))))\n      )\n')

def module_symbol(sym, ref_prefix, value, fp, left, right, names, types, desc):
    """left/right: lists of pin numbers on each side. Returns (text, {pin: (x, y)})."""
    n = max(len(left), len(right))
    h = (n + 1) * 2.54
    top = h / 2
    w = 12.7
    pins, pos = "", {}
    for i, p in enumerate(left):
        y = top - (i + 1) * 2.54
        pins += pin(p, names[p], types[p], -(w + 2.54), y, 0); pos[p] = (-(w + 2.54), y)
    for i, p in enumerate(right):
        y = top - (i + 1) * 2.54
        pins += pin(p, names[p], types[p], (w + 2.54), y, 180); pos[p] = ((w + 2.54), y)
    s = f'''  (symbol "{sym}" (in_bom yes) (on_board yes)
    (property "Reference" "{ref_prefix}" (at 0 {top + 1.27:.2f} 0) (effects (font (size 1.27 1.27))))
    (property "Value" "{value}" (at 0 {-(top + 1.27):.2f} 0) (effects (font (size 1.27 1.27))))
    (property "Footprint" "{fp}" (at 0 0 0) (effects (font (size 1.27 1.27)) hide))
    (property "Datasheet" "https://www.cdebyte.com/products/{value}" (at 0 0 0) (effects (font (size 1.27 1.27)) hide))
    (property "ki_description" "{desc}" (at 0 0 0) (effects (font (size 1.27 1.27)) hide))
    (symbol "{sym}_0_1"
      (rectangle (start {-w:.2f} {top:.2f}) (end {w:.2f} {-top:.2f}) (stroke (width 0.254) (type default)) (fill (type background)))
    )
    (symbol "{sym}_1_1"
{pins}    )
  )
'''
    return s, pos

def conn_symbol(n):
    h = (n + 1) * 2.54; top = h / 2
    pins, pos = "", {}
    for i in range(n):
        y = top - (i + 1) * 2.54
        pins += pin(i + 1, f"Pin_{i+1}", "passive", -5.08, y, 0); pos[i + 1] = (-5.08, y)
    body = ""
    for i in range(n):
        y = top - (i + 1) * 2.54
        body += f'      (rectangle (start -1.27 {y+0.635:.3f}) (end 0 {y-0.635:.3f}) (stroke (width 0.1524) (type default)) (fill (type outline)))\n'
    s = f'''  (symbol "Conn_01x{n}" (in_bom yes) (on_board yes)
    (property "Reference" "J" (at 0 {top + 1.27:.2f} 0) (effects (font (size 1.27 1.27))))
    (property "Value" "Conn_01x{n}" (at 0 {-(top + 1.27):.2f} 0) (effects (font (size 1.27 1.27))))
    (property "Footprint" "EbyteBreakout:PinHeader_1x{n}_P2.54mm_Vertical" (at 0 0 0) (effects (font (size 1.27 1.27)) hide))
    (property "Datasheet" "~" (at 0 0 0) (effects (font (size 1.27 1.27)) hide))
    (property "ki_description" "Generic 1x{n} pin header, breakout output" (at 0 0 0) (effects (font (size 1.27 1.27)) hide))
    (symbol "Conn_01x{n}_0_1"
      (rectangle (start -1.27 {top - 1.27:.2f}) (end 1.27 {-(top - 1.27):.2f}) (stroke (width 0.254) (type default)) (fill (type background)))
{body}    )
    (symbol "Conn_01x{n}_1_1"
{pins}    )
  )
'''
    return s, pos

e07_sym, e07_pos = module_symbol("E07-433M20S", "A", "E07-433M20S", "EbyteBreakout:EBYTE_E07-433M20S",
                                 list(range(1, 13)), [13, 14, 15, 16], E07_NAMES, E07_PIN_TYPE,
                                 "EBYTE E07-433M20S CC1101 433MHz 100mW SPI transceiver module, 18x32mm stamp holes")
e01_sym, e01_pos = module_symbol("E01-2G4M27SX", "B", "E01-2G4M27SX", "EbyteBreakout:EBYTE_E01-2G4M27SX",
                                 list(range(1, 9)), [9, 10], E01_NAMES, E01_PIN_TYPE,
                                 "EBYTE E01-2G4M27SX nRF24L01+ 2.4GHz 27dBm PA/LNA SPI module, 14.5x18mm stamp holes")
conn_sym, conn_pos = conn_symbol(14)

lib = '(kicad_symbol_lib (version 20220914) (generator kicad_symbol_editor)\n' + e07_sym + e01_sym + conn_sym + ')\n'
open(os.path.join(OUTDIR, "EbyteBreakout.kicad_sym"), "w").write(lib)

# ---------------- schematic ----------------
def prefixed(sym):
    return sym.replace(f'(symbol "{sym_name(sym)}"', f'(symbol "EbyteBreakout:{sym_name(sym)}"', 1) \
              .replace(f'(symbol "{sym_name(sym)}_', f'(symbol "{sym_name(sym)}_')

def sym_name(s):
    return s.split('"')[1]

lib_symbols = "  (lib_symbols\n" + "".join(prefixed(x).replace("\n  (symbol", "\n    (symbol") for x in (e07_sym, e01_sym, conn_sym)) + "  )\n"

items = []
def place(lib_id, ref, value, fp, x, y, pos, nets, datasheet="~"):
    """Place a symbol at (x,y). nets: {pin: netname or None(NC)}."""
    pins_txt = "".join(f'    (pin "{p}" (uuid "{U()}"))\n' for p in pos)
    top = max(py for _, py in pos.values()) + 2.54 + 1.27
    items.append(f'''  (symbol (lib_id "{lib_id}") (at {x:.2f} {y:.2f} 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid "{U()}")
    (property "Reference" "{ref}" (at {x:.2f} {y - top:.2f} 0) (effects (font (size 1.27 1.27))))
    (property "Value" "{value}" (at {x:.2f} {y + top:.2f} 0) (effects (font (size 1.27 1.27))))
    (property "Footprint" "{fp}" (at {x:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) hide))
    (property "Datasheet" "{datasheet}" (at {x:.2f} {y:.2f} 0) (effects (font (size 1.27 1.27)) hide))
{pins_txt}    (instances (project "{NAME}" (path "/{ROOT}" (reference "{ref}") (unit 1))))
  )
''')
    for p, (px, py) in pos.items():
        sx, sy = x + px, y - py          # schematic y is flipped vs. library y
        n = nets.get(p)
        if n is None:
            items.append(f'  (no_connect (at {sx:.2f} {sy:.2f}) (uuid "{U()}"))\n')
            continue
        d = -1 if px < 0 else 1
        ex = sx + d * 5.08
        items.append(f'  (wire (pts (xy {sx:.2f} {sy:.2f}) (xy {ex:.2f} {sy:.2f})) (stroke (width 0) (type default)) (uuid "{U()}"))\n')
        rot, just = (180, "right") if d < 0 else (0, "left")
        items.append(f'  (global_label "{n}" (shape passive) (at {ex:.2f} {sy:.2f} {rot}) (fields_autoplaced)\n'
                     f'    (effects (font (size 1.27 1.27)) (justify {just}))\n    (uuid "{U()}")\n'
                     f'    (property "Intersheetrefs" "${{INTERSHEET_REFS}}" (at {ex:.2f} {sy:.2f} 0) (effects (font (size 1.27 1.27)) hide))\n  )\n')

e07_nets = {p: (None if n in ("NC", "ANT") else n) for p, n in E07_PINS.items()}
place("EbyteBreakout:E07-433M20S", "A1", "E07-433M20S", "EbyteBreakout:EBYTE_E07-433M20S",
      63.5, 63.5, e07_pos, e07_nets, "https://www.cdebyte.com/products/E07-433M20S")
place("EbyteBreakout:E01-2G4M27SX", "B1", "E01-2G4M27SX", "EbyteBreakout:EBYTE_E01-2G4M27SX",
      63.5, 127.0, e01_pos, E01_PINS, "https://www.cdebyte.com/products/E01-2G4M27SX")
place("EbyteBreakout:Conn_01x14", "J1", "Conn_01x14", "EbyteBreakout:PinHeader_1x14_P2.54mm_Vertical",
      177.8, 88.9, conn_pos, {pin: name for pin, name, _ in HEADER})

# notes
notes = []
def note(txt, x, y, size=1.5):
    t = txt.replace('"', '\\"')
    notes.append(f'  (text "{t}" (at {x:.2f} {y:.2f} 0)\n    (effects (font (size {size} {size})) (justify left bottom))\n    (uuid "{U()}")\n  )\n')
note("E07 + E01 combo breakout", 25.4, 20.0, 3.0)
note("A = E07-433M20S (CC1101, 433 MHz)    B = E01-2G4M27SX (nRF24L01+, 2.4 GHz)", 25.4, 25.0)
note("Shared (AB): VCC, GND, SCK, MOSI, MISO.  Separate chip selects and control pins per module.", 25.4, 29.0)
note("VCC: 2.3 - 3.6 V (E01 min 2.3 V, E07 min 2.1 V). Both modules are 3.3 V logic only.", 25.4, 33.0)
note("E07 pin 13 (ANT stamp pad) intentionally unconnected: use the module's IPEX connector.", 25.4, 37.0)
hdr_note = "J1 pinout: " + "  ".join(f"{p}:{n}({t})" for p, n, t in HEADER)
note(hdr_note, 25.4, 41.0, 1.27)

sch = f'''(kicad_sch (version 20230121) (generator eeschema)

  (uuid "{ROOT}")

  (paper "A4")

  (title_block
    (title "E07 + E01 combo breakout")
    (date "2026-10-07")
    (rev "1.0")
    (company "hey-its-brian")
    (comment 1 "EBYTE E07-433M20S (A) + E01-2G4M27SX (B) on one board, shared SPI bus to a 1x14 header")
  )

{lib_symbols}
{"".join(notes)}{"".join(items)}
  (sheet_instances
    (path "/" (page "1"))
  )
)
'''
open(os.path.join(OUTDIR, NAME + ".kicad_sch"), "w").write(sch)

# ---------------- lib tables + project ----------------
open(os.path.join(OUTDIR, "sym-lib-table"), "w").write(
    '(sym_lib_table\n  (version 7)\n  (lib (name "EbyteBreakout")(type "KiCad")(uri "${KIPRJMOD}/EbyteBreakout.kicad_sym")(options "")(descr "Project symbols"))\n)\n')
open(os.path.join(OUTDIR, "fp-lib-table"), "w").write(
    '(fp_lib_table\n  (version 7)\n  (lib (name "EbyteBreakout")(type "KiCad")(uri "${KIPRJMOD}/EbyteBreakout.pretty")(options "")(descr "Project footprints"))\n)\n')

pro = {
    "board": {"design_settings": {"defaults": {}, "rules": {
        "min_clearance": 0.15, "min_copper_edge_clearance": 0.3, "min_hole_clearance": 0.25,
        "min_silk_clearance": 0.0, "min_text_height": 0.5, "min_text_thickness": 0.1,
        "min_through_hole_diameter": 0.3, "min_track_width": 0.2, "min_via_diameter": 0.45}},
        "layer_presets": [], "viewports": []},
    "boards": [], "cvpcb": {"equivalence_files": []}, "libraries": {"pinned_footprint_libs": [], "pinned_symbol_libs": []},
    "meta": {"filename": NAME + ".kicad_pro", "version": 1},
    "net_settings": {"classes": [{"bus_width": 12, "clearance": CLEARANCE, "diff_pair_gap": 0.25, "diff_pair_via_gap": 0.25,
                                   "diff_pair_width": 0.2, "line_style": 0, "microvia_diameter": 0.3, "microvia_drill": 0.1,
                                   "name": "Default", "pcb_color": "rgba(0, 0, 0, 0.000)", "schematic_color": "rgba(0, 0, 0, 0.000)",
                                   "track_width": TRACK_W, "via_diameter": VIA_D, "via_drill": VIA_DRILL, "wire_width": 6}],
                     "meta": {"version": 3}, "net_colors": None, "netclass_assignments": None, "netclass_patterns": []},
    "pcbnew": {"last_paths": {"gencad": "", "idf": "", "netlist": "", "specctra_dsn": "", "step": "", "vrml": ""}, "page_layout_descr_file": ""},
    "schematic": {"legacy_lib_dir": "", "legacy_lib_list": []},
    "sheets": [[ROOT, ""]], "text_variables": {}
}
json.dump(pro, open(os.path.join(OUTDIR, NAME + ".kicad_pro"), "w"), indent=2)
print("schematic + libs written")
