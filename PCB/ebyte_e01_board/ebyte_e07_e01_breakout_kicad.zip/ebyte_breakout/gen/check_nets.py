import re, sys, pcbnew
txt = open(sys.argv[1]).read()
sch = {}
cur = None
for line in txt.splitlines():
    m = re.search(r'\(net \(code "\d+"\) \(name "([^"]+)"\)', line)
    if m: cur = m.group(1)
    m = re.search(r'\(node \(ref "(\w+)"\) \(pin "(\d+)"\)', line)
    if m and cur: sch[(m.group(1), m.group(2))] = cur
b = pcbnew.LoadBoard(sys.argv[2])
pcb = {}
for fp in b.GetFootprints():
    for p in fp.Pads():
        if p.GetNetname(): pcb[(fp.GetReference(), p.GetNumber())] = p.GetNetname()
bad = 0
for k in sorted(set(sch) | set(pcb)):
    s, p = sch.get(k), pcb.get(k)
    if s and (s.startswith("Net-") or s.startswith("unconnected")): s = None
    if s != p: print("MISMATCH", k, "sch=", s, "pcb=", p); bad += 1
print(f"sch nodes {len(sch)}  pcb nodes {len(pcb)}  mismatches {bad}")
