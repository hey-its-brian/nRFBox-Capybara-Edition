#!/bin/bash
set -e
cd "$(dirname "$0")/.."
rm -rf kicad/EbyteBreakout.pretty
python3 gen/build_pcb.py kicad/ebyte_e07_e01_breakout.kicad_pcb kicad/EbyteBreakout.pretty
python3 gen/fill_zones.py kicad/ebyte_e07_e01_breakout.kicad_pcb
cd kicad && python3 -c "
import pcbnew
b=pcbnew.LoadBoard('ebyte_e07_e01_breakout.kicad_pcb')
pcbnew.WriteDRCReport(b,'drc.rpt',pcbnew.EDA_UNITS_MILLIMETRES,True)"
grep -E "^\[" drc.rpt | sort | uniq -c | sort -rn
