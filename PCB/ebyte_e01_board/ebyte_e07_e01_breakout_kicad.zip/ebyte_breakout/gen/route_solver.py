"""Find a back-layer-only routing: bus rows on B.Cu, pad drops and header drops on B.Cu.

Segment = one (pad, header pin) pair of a net: horizontal B.Cu run at row r spanning
[min(xp, xh), max(xp, xh)], with a vertical from the pad via (at VIA_Y) down to the row
and a vertical from the header pin up to the row.
A pad drop of segment t at x crosses every row ABOVE r_t; a header drop crosses every row
BELOW r_t. Neither may cross a different net's segment that spans that x.
"""
import itertools, random, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from design import *

VIA_Y = 36.3            # pad vias sit right below the module pad row
ROW_TOP = 37.4
ROW_BOT = 45.1
GAP = 0.6               # min x gap between segments sharing a row

def pad_xs():
    xs = {}
    for n, name in E07_PINS.items():
        if name in ROUTED_NETS: xs.setdefault(name, []).append(E07_X + e07_pad_local(n)[0])
    for n, name in E01_PINS.items():
        if name in ROUTED_NETS: xs.setdefault(name, []).append(E01_X + e01_pad_local(n)[0])
    return xs

def segments(order):
    """order: list of 12 net names for header pins 2..13."""
    hx = {n: hdr_x(i + 2) for i, n in enumerate(order)}
    segs = []
    for net, xs in pad_xs().items():
        for xp in xs:
            segs.append((net, xp, hx[net], min(xp, hx[net]), max(xp, hx[net])))
    return segs

def solve(order, nrows):
    segs = segments(order)
    S = len(segs)
    # conflict matrix: must[a][b] in {'above','below',None}; same-row-ok[a][b]
    def inside(x, s): return s[3] - 0.2 <= x <= s[4] + 0.2
    need = {}
    for a in range(S):
        for b in range(S):
            if a == b or segs[a][0] == segs[b][0]: continue
            sa, sb = segs[a], segs[b]
            c = set()
            if inside(sb[1], sa): c.add("a_below_b")   # pad drop of b crosses rows above r_b
            if inside(sb[2], sa): c.add("a_above_b")   # header drop of b crosses rows below r_b
            if c: need[(a, b)] = c
    # hard contradictions
    for (a, b), c in need.items():
        if c == {"a_below_b", "a_above_b"}: return None
    def overlap(a, b):
        return not (segs[a][4] + GAP < segs[b][3] or segs[b][4] + GAP < segs[a][3])
    row = [None] * S
    order_idx = sorted(range(S), key=lambda i: -(segs[i][4] - segs[i][3]))  # long spans first
    def ok(i, r):
        for j in range(S):
            if row[j] is None or j == i: continue
            if segs[i][0] != segs[j][0] and row[j] == r and overlap(i, j): return False
            if segs[i][0] == segs[j][0] and row[j] == r: pass
            for (a, b), c in ((( i, j), need.get((i, j), set())), ((j, i), need.get((j, i), set()))):
                ra, rb = (r, row[j]) if a == i else (row[j], r)
                if "a_below_b" in c and not ra > rb: return False
                if "a_above_b" in c and not ra < rb: return False
        return True
    def bt(k):
        if k == S: return True
        i = order_idx[k]
        for r in range(nrows):
            if ok(i, r):
                row[i] = r
                if bt(k + 1): return True
                row[i] = None
        return False
    if bt(0): return segs, row
    return None

def search(nrows):
    base = ["MOSI", "SCK", "MISO", "GDO2", "GDO0", "CSN_A", "TX_EN", "RX_EN", "VCC", "CE", "CSN_B", "IRQ"]
    tried = [base]
    r = solve(base, nrows)
    if r: return base, r
    rng = random.Random(1)
    for _ in range(20000):
        o = base[:]
        # local perturbations keep A nets left, B nets right
        i, j = rng.sample(range(12), 2); o[i], o[j] = o[j], o[i]
        r = solve(o, nrows)
        if r: return o, r
    return None, None

if __name__ == "__main__":
    nrows = int(sys.argv[1]) if len(sys.argv) > 1 else 11
    order, res = search(nrows)
    print("order:", order)
    if res:
        segs, row = res
        for s, r in sorted(zip(segs, row), key=lambda t: t[1]):
            print(f"row {r:2d}  {s[0]:6s} pad {s[1]:6.2f} hdr {s[2]:6.2f}")
