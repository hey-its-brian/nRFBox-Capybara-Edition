import sys, os
import pcbnew
from pcbnew import VECTOR2I, EDA_ANGLE, DEGREES_T
sys.path.insert(0, os.path.dirname(__file__))
from design import *

OUT = sys.argv[1]
LIBDIR = sys.argv[2]   # EbyteBreakout.pretty

def mm(v): return pcbnew.FromMM(v)
def P(x, y): return VECTOR2I(mm(x), mm(y))

board = pcbnew.BOARD()
ds = board.GetDesignSettings()
nc = ds.m_NetSettings.m_DefaultNetClass
nc.SetClearance(mm(CLEARANCE)); nc.SetTrackWidth(mm(TRACK_W))
nc.SetViaDiameter(mm(VIA_D)); nc.SetViaDrill(mm(VIA_DRILL))
ds.m_MinClearance = mm(0.15); ds.m_TrackMinWidth = mm(0.2)
ds.m_ViasMinSize = mm(0.45); ds.m_MinThroughDrill = mm(0.3)
ds.m_CopperEdgeClearance = mm(0.3)
ds.m_MinSilkTextHeight = mm(0.5); ds.m_MinSilkTextThickness = mm(0.1)

nets = {}
def net(name):
    if name not in nets:
        n = pcbnew.NETINFO_ITEM(board, name); board.Add(n); nets[name] = n
    return nets[name]
for n in ["GND", "VCC"] + ROUTED_NETS: net(n)

def text(s, x, y, layer, size=1.0, angle=0, mirror=False, thick=None, hj=None):
    t = pcbnew.PCB_TEXT(board)
    t.SetText(s); t.SetPosition(P(x, y)); t.SetLayer(layer)
    t.SetTextSize(VECTOR2I(mm(size), mm(size)))
    t.SetTextThickness(mm(max(0.12, thick if thick else size * 0.15)))
    t.SetTextAngle(EDA_ANGLE(angle, DEGREES_T))
    t.SetMirrored(mirror)
    if hj is not None: t.SetHorizJustify(hj)
    board.Add(t); return t

def fp_text(fp, s, x, y, layer, size=1.0, angle=0):
    t = pcbnew.FP_TEXT(fp)
    t.SetText(s); t.SetPos0(P(x, y)); t.SetPosition(P(x, y)); t.SetLayer(layer)
    t.SetTextSize(VECTOR2I(mm(size), mm(size))); t.SetTextThickness(mm(max(0.12, size * 0.15)))
    t.SetTextAngle(EDA_ANGLE(angle, DEGREES_T))
    fp.Add(t); return t

def fp_rect(fp, x1, y1, x2, y2, layer, w=0.12):
    s = pcbnew.FP_SHAPE(fp); s.SetShape(pcbnew.SHAPE_T_RECT)
    s.SetStart0(P(x1, y1)); s.SetEnd0(P(x2, y2)); s.SetStart(P(x1, y1)); s.SetEnd(P(x2, y2)); s.SetLayer(layer); s.SetWidth(mm(w))
    s.SetFilled(False); fp.Add(s); return s

def fp_line(fp, x1, y1, x2, y2, layer, w=0.12):
    s = pcbnew.FP_SHAPE(fp); s.SetShape(pcbnew.SHAPE_T_SEGMENT)
    s.SetStart0(P(x1, y1)); s.SetEnd0(P(x2, y2)); s.SetStart(P(x1, y1)); s.SetEnd(P(x2, y2)); s.SetLayer(layer); s.SetWidth(mm(w))
    fp.Add(s); return s

def smd_pad(fp, num, x, y, w, h):
    p = pcbnew.PAD(fp); p.SetNumber(str(num))
    p.SetAttribute(pcbnew.PAD_ATTRIB_SMD); p.SetShape(pcbnew.PAD_SHAPE_ROUNDRECT)
    p.SetRoundRectRadiusRatio(0.2)
    p.SetSize(VECTOR2I(mm(w), mm(h))); p.SetPos0(P(x, y)); p.SetPosition(P(x, y))
    p.SetLayerSet(pcbnew.PAD.SMDMask()); fp.Add(p); return p

def tht_pad(fp, num, x, y, dia, drill, square=False):
    p = pcbnew.PAD(fp); p.SetNumber(str(num))
    p.SetAttribute(pcbnew.PAD_ATTRIB_PTH)
    p.SetShape(pcbnew.PAD_SHAPE_RECT if square else pcbnew.PAD_SHAPE_CIRCLE)
    p.SetSize(VECTOR2I(mm(dia), mm(dia))); p.SetDrillSize(VECTOR2I(mm(drill), mm(drill)))
    p.SetPos0(P(x, y)); p.SetPosition(P(x, y)); p.SetLayerSet(pcbnew.PAD.PTHMask()); fp.Add(p); return p

def new_fp(ref, name, value, desc):
    fp = pcbnew.FOOTPRINT(board)
    fp.SetReference(ref); fp.SetValue(value)
    fp.SetFPID(pcbnew.LIB_ID("EbyteBreakout", name))
    fp.SetDescription(desc)
    return fp

# ---------------- Module A: E07-433M20S ----------------
def build_e07():
    fp = new_fp("A1", "EBYTE_E07-433M20S", "E07-433M20S",
                "EBYTE E07-433M20S CC1101 433MHz module, 18x32mm, 1.27mm stamp holes (rotated 180 deg: signal row at bottom)")
    fp.SetAttributes(pcbnew.FP_SMD)
    for n in range(1, 17):
        x, y = e07_pad_local(n)
        if n <= 12:
            smd_pad(fp, n, x, y, 0.9, 1.6)
        elif n == 13:
            smd_pad(fp, n, x, y, 1.0, 2.4)
        else:
            smd_pad(fp, n, x, y, 0.9, 1.6)
    fp_rect(fp, 0, 0, E07_W, E07_H, pcbnew.F_Fab, 0.1)
    fp_rect(fp, 0, 0, E07_W, E07_H, pcbnew.F_CrtYd, 0.05)
    # silk outline, leaving gaps at pad rows
    fp_line(fp, 0, 1.2, 0, E07_H - 1.2, pcbnew.F_SilkS)
    fp_line(fp, E07_W, 1.2, E07_W, E07_H - 1.2, pcbnew.F_SilkS)
    # pin-1 marker (pad 1 is bottom-left after rotation)
    x1, y1 = e07_pad_local(1)
    fp_line(fp, x1 - 0.8, y1 + 1.1, x1 + 0.8, y1 + 1.1, pcbnew.F_SilkS, 0.2)
    fp_text(fp, "A", E07_W / 2, 8.0, pcbnew.F_SilkS, 4.0)
    fp_text(fp, "E07-433M20S", E07_W / 2, 13.0, pcbnew.F_SilkS, 1.0)
    fp_text(fp, "CC1101 433MHz", E07_W / 2, 14.8, pcbnew.F_SilkS, 0.8)
    fp_text(fp, "IPEX ANT", E07_W - 4.6, 6.2, pcbnew.F_SilkS, 0.6)
    for n in range(1, 13):
        x, y = e07_pad_local(n)
        fp_text(fp, E07_PINS[n], x, y - 2.6, pcbnew.F_SilkS, 0.55, 90)
    for n in (13, 14, 15, 16):
        x, y = e07_pad_local(n)
        fp_text(fp, E07_PINS[n], x, y + 2.9, pcbnew.F_SilkS, 0.55, 90)
    fp.Reference().SetPos0(P(E07_W / 2, 19.0)); fp.Reference().SetPosition(P(E07_W / 2, 19.0)); fp.Reference().SetLayer(pcbnew.F_SilkS)
    fp.Reference().SetTextSize(VECTOR2I(mm(1.0), mm(1.0))); fp.Reference().SetTextThickness(mm(0.15))
    fp.Value().SetPos0(P(E07_W / 2, 21.0)); fp.Value().SetPosition(P(E07_W / 2, 21.0)); fp.Value().SetLayer(pcbnew.F_Fab)
    return fp

# ---------------- Module B: E01-2G4M27SX ----------------
def build_e01():
    fp = new_fp("B1", "EBYTE_E01-2G4M27SX", "E01-2G4M27SX",
                "EBYTE E01-2G4M27SX nRF24L01+ 2.4GHz PA/LNA module, 14.5x18mm, 1.27mm stamp holes (rotated 180 deg: signal row at bottom)")
    fp.SetAttributes(pcbnew.FP_SMD)
    for n in range(1, 11):
        x, y = e01_pad_local(n)
        if n <= 8:
            smd_pad(fp, n, x, y, 0.9, 1.6)
        else:
            smd_pad(fp, n, x, y, 1.6, 1.5)
    fp_rect(fp, 0, 0, E01_W, E01_H, pcbnew.F_Fab, 0.1)
    fp_rect(fp, 0, 0, E01_W, E01_H, pcbnew.F_CrtYd, 0.05)
    fp_line(fp, 1.0, 0, E01_W - 1.0, 0, pcbnew.F_SilkS)
    fp_line(fp, 0, 1.0, 0, E01_H - 13.0 - 1.3, pcbnew.F_SilkS)
    fp_line(fp, 0, E01_H - 13.0 + 1.3, 0, E01_H - 1.2, pcbnew.F_SilkS)
    fp_line(fp, E01_W, 1.0, E01_W, E01_H - 13.0 - 1.3, pcbnew.F_SilkS)
    fp_line(fp, E01_W, E01_H - 13.0 + 1.3, E01_W, E01_H - 1.2, pcbnew.F_SilkS)
    x1, y1 = e01_pad_local(1)
    fp_line(fp, x1 - 0.8, y1 + 1.1, x1 + 0.8, y1 + 1.1, pcbnew.F_SilkS, 0.2)
    fp_text(fp, "B", E01_W / 2, 5.0, pcbnew.F_SilkS, 4.0)
    fp_text(fp, "E01-2G4M27SX", E01_W / 2, 9.0, pcbnew.F_SilkS, 0.85)
    fp_text(fp, "nRF24L01+ 2.4GHz", E01_W / 2, 10.6, pcbnew.F_SilkS, 0.7)
    for n in range(1, 9):
        x, y = e01_pad_local(n)
        fp_text(fp, E01_PINS[n], x, y - 2.6, pcbnew.F_SilkS, 0.55, 90)
    fp.Reference().SetPos0(P(E01_W / 2, 12.6)); fp.Reference().SetPosition(P(E01_W / 2, 12.6)); fp.Reference().SetLayer(pcbnew.F_SilkS)
    fp.Reference().SetTextSize(VECTOR2I(mm(1.0), mm(1.0))); fp.Reference().SetTextThickness(mm(0.15))
    fp.Value().SetPos0(P(E01_W / 2, 14.2)); fp.Value().SetPosition(P(E01_W / 2, 14.2)); fp.Value().SetLayer(pcbnew.F_Fab)
    return fp

# ---------------- Header J1 ----------------
def build_hdr():
    fp = new_fp("J1", "PinHeader_1x14_P2.54mm_Vertical", "Conn_01x14",
                "Through hole straight pin header, 1x14, 2.54mm pitch")
    fp.SetAttributes(pcbnew.FP_THROUGH_HOLE)
    for i in range(14):
        tht_pad(fp, i + 1, i * HDR_PITCH, 0, 1.7, 1.0, square=(i == 0))
    L = 13 * HDR_PITCH
    fp_rect(fp, -1.27, -1.27, L + 1.27, 1.27, pcbnew.F_Fab, 0.1)
    fp_rect(fp, -1.27, -1.27, L + 1.27, 1.27, pcbnew.F_SilkS, 0.12)
    fp_rect(fp, -1.52, -1.52, L + 1.52, 1.52, pcbnew.F_CrtYd, 0.05)
    fp.Reference().SetPos0(P(L / 2, 2.6)); fp.Reference().SetPosition(P(L / 2, 2.6)); fp.Reference().SetLayer(pcbnew.F_Fab)
    fp.Reference().SetTextSize(VECTOR2I(mm(0.8), mm(0.8))); fp.Reference().SetTextThickness(mm(0.12))
    fp.Value().SetPos0(P(L / 2, 0)); fp.Value().SetPosition(P(L / 2, 0)); fp.Value().SetLayer(pcbnew.F_Fab)
    return fp

# ---------------- Mounting hole ----------------
def build_hole(ref):
    fp = new_fp(ref, "MountingHole_2.2mm_M2", "M2", "M2 mounting hole, 2.2mm")
    fp.SetAttributes(pcbnew.FP_THROUGH_HOLE)
    p = tht_pad(fp, 1, 0, 0, 4.0, 2.2)
    p.SetAttribute(pcbnew.PAD_ATTRIB_NPTH); p.SetLayerSet(pcbnew.PAD.UnplatedHoleMask())
    p.SetSize(VECTOR2I(mm(2.2), mm(2.2)))
    c = pcbnew.FP_SHAPE(fp); c.SetShape(pcbnew.SHAPE_T_CIRCLE)
    c.SetStart0(P(0, 0)); c.SetEnd0(P(2.2, 0)); c.SetStart(P(0, 0)); c.SetEnd(P(2.2, 0)); c.SetLayer(pcbnew.F_CrtYd); c.SetWidth(mm(0.05)); fp.Add(c)
    fp.Reference().SetLayer(pcbnew.F_Fab); fp.Reference().SetPos0(P(0, 3.0)); fp.Reference().SetPosition(P(0, 3.0))
    fp.Value().SetLayer(pcbnew.F_Fab); fp.Value().SetPos0(P(0, -3.0)); fp.Value().SetPosition(P(0, -3.0))
    return fp

# Save pristine footprints into the project library, then place on board
io = pcbnew.IO_MGR.PluginFind(pcbnew.IO_MGR.KICAD_SEXP)
if not os.path.isdir(LIBDIR):
    io.FootprintLibCreate(LIBDIR)
placed = {}
for builder, pos in [(build_e07, (E07_X, E07_Y)), (build_e01, (E01_X, E01_Y)),
                     (build_hdr, (HDR_X0, HDR_Y)),
                     (lambda: build_hole("H1"), (25.0, 5.0)),
                     (lambda: build_hole("H2"), (37.5, 5.0))]:
    fp = builder()
    io.FootprintSave(LIBDIR, fp)
    fp.Move(P(*pos))
    board.Add(fp)
    placed[fp.GetReference()] = fp

# assign nets to pads
A1, B1, J1 = placed["A1"], placed["B1"], placed["J1"]
for pad in A1.Pads():
    n = E07_PINS[int(pad.GetNumber())]
    if n not in ("NC", "ANT"): pad.SetNet(net(n))
for pad in B1.Pads():
    pad.SetNet(net(E01_PINS[int(pad.GetNumber())]))
for pad in J1.Pads():
    pad.SetNet(net(HEADER[int(pad.GetNumber()) - 1][1]))

# ---------------- Routing ----------------
def track(x1, y1, x2, y2, n, layer, w=TRACK_W):
    t = pcbnew.PCB_TRACK(board); t.SetStart(P(x1, y1)); t.SetEnd(P(x2, y2))
    t.SetWidth(mm(w)); t.SetLayer(layer); t.SetNet(net(n)); board.Add(t)

def via(x, y, n):
    v = pcbnew.PCB_VIA(board); v.SetPosition(P(x, y)); v.SetDrill(mm(VIA_DRILL))
    v.SetWidth(mm(VIA_D)); v.SetViaType(pcbnew.VIATYPE_THROUGH)
    v.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu); v.SetNet(net(n)); board.Add(v)

def pad_abs(fp_local, origin, n):
    x, y = fp_local(n); return (origin[0] + x, origin[1] + y)

hdr_of = {name: pin for pin, name, _ in HEADER if name != "GND"}
E07_ORIGIN, E01_ORIGIN = (E07_X, E07_Y), (E01_X, E01_Y)

def pad_via(fp_local, origin, num, n):
    """Short F.Cu stub from the module pad straight down to a via at VIA_Y. Returns via x."""
    px, py = pad_abs(fp_local, origin, num)
    track(px, py, px, VIA_Y, n, pcbnew.F_Cu); via(px, VIA_Y, n)
    return px

def to_header(x, n, pin):
    """B.Cu diagonal from a via at (x, VIA_Y) to header pin."""
    track(x, VIA_Y, hdr_x(pin), HDR_Y, n, pcbnew.B_Cu)

# Module A (E07): every routed pad -> via -> diagonal to its header pin, except MISO
# which joins the shared MISO bus directly (see below).
for num, n in E07_PINS.items():
    if n in ("NC", "ANT", "GND", "MISO"): continue
    x = pad_via(e07_pad_local, E07_ORIGIN, num, n)
    to_header(x, n, hdr_of[n])
    if n in ("MOSI", "SCK"):
        track(x, VIA_Y, x, BUS_Y[n], n, pcbnew.B_Cu)      # up to the shared bus
# Module B (E01): VCC/CE/CSN_B/MISO/IRQ -> diagonals; SCK/MOSI go up to the shared bus
for num, n in E01_PINS.items():
    if n == "GND": continue
    x = pad_via(e01_pad_local, E01_ORIGIN, num, n)
    if n in ("MOSI", "SCK"):
        track(x, VIA_Y, x, BUS_Y[n], n, pcbnew.B_Cu)
    else:
        to_header(x, n, hdr_of[n])
    if n == "MISO":
        track(x, VIA_Y, x, BUS_Y[n], n, pcbnew.B_Cu)
# Shared buses on B.Cu, running under the modules (nothing else is on the back there)
e07x = {n: pad_abs(e07_pad_local, E07_ORIGIN, num)[0] for num, n in E07_PINS.items()}
e01x = {n: pad_abs(e01_pad_local, E01_ORIGIN, num)[0] for num, n in E01_PINS.items()}
for n in ("MOSI", "SCK", "MISO"):
    track(e07x[n], BUS_Y[n], e01x[n], BUS_Y[n], n, pcbnew.B_Cu)
# E07 MISO: F.Cu stub runs up under the module body to a via sitting on the MISO bus
mx, my = pad_abs(e07_pad_local, E07_ORIGIN, 4)
track(mx, my, mx, BUS_Y["MISO"], "MISO", pcbnew.F_Cu); via(mx, BUS_Y["MISO"], "MISO")

# GND: explicit B.Cu stitches to the two header GND pins (zones do the rest)
gx = pad_via(e07_pad_local, E07_ORIGIN, 1, "GND"); to_header(gx, "GND", 1)
gx = pad_via(e01_pad_local, E01_ORIGIN, 8, "GND"); to_header(gx, "GND", 14)

# ---------------- Board outline ----------------
o = pcbnew.PCB_SHAPE(board); o.SetShape(pcbnew.SHAPE_T_RECT)
o.SetStart(P(0, 0)); o.SetEnd(P(BOARD_W, BOARD_H)); o.SetLayer(pcbnew.Edge_Cuts); o.SetWidth(mm(0.1))
board.Add(o)

# ---------------- Zones ----------------
def zone(layer, pts, n=None, keepout=False):
    z = pcbnew.ZONE(board)
    if layer is not None: z.SetLayer(layer)
    ol = z.Outline(); ol.NewOutline()
    for x, y in pts: ol.Append(mm(x), mm(y))
    if keepout:
        z.SetIsRuleArea(True); z.SetDoNotAllowCopperPour(True)
        z.SetLayerSet(pcbnew.LSET.AllCuMask(2))
    else:
        z.SetNet(net(n)); z.SetLocalClearance(mm(0.25)); z.SetMinThickness(mm(0.25))
        z.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)
        z.SetThermalReliefGap(mm(0.3)); z.SetThermalReliefSpokeWidth(mm(0.4))
        z.SetZoneName("GND_" + ("F" if layer == pcbnew.F_Cu else "B"))
    board.Add(z); return z

ax, ay = pad_abs(e07_pad_local, (E07_X, E07_Y), 13)
nx1, nx2, ny = ax - 0.9, E07_X + E07_W + 0.5, ay + 3.5   # notch: no copper under E07 ANT pad corner
full = [(0, 0), (nx1, 0), (nx1, ny), (nx2, ny), (nx2, 0), (BOARD_W, 0), (BOARD_W, BOARD_H), (0, BOARD_H)]
zone(pcbnew.F_Cu, full, "GND"); zone(pcbnew.B_Cu, full, "GND")

# ---------------- Board-level silkscreen ----------------
TX = 31.5
text("E07 + E01 BREAKOUT", TX, 10.0, pcbnew.F_SilkS, 0.9, thick=0.15)
text("A = E07-433M20S", TX, 11.8, pcbnew.F_SilkS, 0.65)
text("B = E01-2G4M27SX", TX, 13.1, pcbnew.F_SilkS, 0.65)
text("AB = shared bus pin", TX, 14.4, pcbnew.F_SilkS, 0.65)
text("ANT pad NC, use IPEX", 7.2, 1.4, pcbnew.F_SilkS, 0.6)
# output pin labels: front reads upward from just above the header; back mirrored
for pin, name, tag in HEADER:
    x = hdr_x(pin)
    lbl = f"{name} {tag}"
    text(lbl, x + 1.27, 44.9, pcbnew.F_SilkS, 0.75, angle=90, thick=0.13, hj=pcbnew.GR_TEXT_H_ALIGN_LEFT)
    text(lbl, x + 1.27, 44.9, pcbnew.B_SilkS, 0.75, angle=90, thick=0.13, mirror=True, hj=pcbnew.GR_TEXT_H_ALIGN_RIGHT)
text("1", hdr_x(1) - 1.9, HDR_Y + 0.05, pcbnew.F_SilkS, 0.8)
text("14", hdr_x(14) + 2.1, HDR_Y + 0.05, pcbnew.F_SilkS, 0.8)
text("A = E07   B = E01   AB = shared", 20.25, 48.7, pcbnew.F_SilkS, 0.7)
text("1", hdr_x(1) - 1.9, HDR_Y + 0.05, pcbnew.B_SilkS, 0.8, mirror=True)
text("14", hdr_x(14) + 2.1, HDR_Y + 0.05, pcbnew.B_SilkS, 0.8, mirror=True)
text("SPI: A = CC1101 (433MHz)   B = nRF24L01+ (2.4GHz)", 20.25, 2.0, pcbnew.B_SilkS, 0.7, mirror=True)
text("Shared SCK / MOSI / MISO / VCC / GND   VCC 2.3 - 3.6V", 20.25, 3.4, pcbnew.B_SilkS, 0.7, mirror=True)
text("hey-its-brian   v1.0   2026-10", 20.25, 49.0, pcbnew.B_SilkS, 0.6, mirror=True)

# ---------------- Fill zones and save ----------------
pcbnew.SaveBoard(OUT, board)
print("saved", OUT)
