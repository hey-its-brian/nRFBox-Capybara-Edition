# EBYTE E07 + E01 combo breakout

Carrier PCB that takes an **EBYTE E07-433M20S** (CC1101, 433 MHz, labelled **A**) and an
**EBYTE E01-2G4M27SX** (nRF24L01+ PA/LNA, 2.4 GHz, labelled **B**), soldered directly to
their 1.27 mm stamp-hole pads, with the shared SPI/power lines bridged on the board and
everything brought out to one 1x14 2.54 mm header (J1).

Board: 40.5 x 50 mm, 2 layer, ground pour both sides, two M2 mounting holes.
All signal routing is on the back layer (header order follows the module pad order so the
fan-out never crosses); the front carries only pads, pour and silkscreen.
Designed in KiCad 7.0 (opens in 7, 8 and 9).

## J1 pinout (left to right, pin 1 is the square pad)

| Pin | Net   | Goes to | Notes |
|----:|-------|:-------:|-------|
| 1   | GND   | AB      | |
| 2   | MOSI  | AB      | shared SPI |
| 3   | SCK   | AB      | shared SPI |
| 4   | GDO2  | A       | CC1101 GDO2 |
| 5   | GDO0  | A       | CC1101 GDO0 (packet interrupt) |
| 6   | CSN_A | A       | CC1101 chip select |
| 7   | TX_EN | A       | E07 PA enable, active high, not with RX_EN |
| 8   | RX_EN | A       | E07 LNA enable, active high, not with TX_EN |
| 9   | VCC   | AB      | 2.3 to 3.6 V, 3.3 V recommended |
| 10  | CE    | B       | nRF24 chip enable |
| 11  | CSN_B | B       | nRF24 chip select |
| 12  | MISO  | AB      | shared SPI |
| 13  | IRQ   | B       | nRF24 interrupt, active low |
| 14  | GND   | AB      | |

Both modules are 3.3 V logic. Budget roughly 150 mA for the E07 at full power and up to
~115 mA for the E01 at 27 dBm; a 3.3 V regulator rated for at least 300 mA is sensible.

The E07's ANT stamp pad (pin 13) is deliberately left unconnected with a copper notch
under it; use the module's IPEX connector for the antenna. The E01 has IPEX only.

## Files

- `kicad/ebyte_e07_e01_breakout.kicad_pro` / `.kicad_sch` / `.kicad_pcb`: the KiCad project
- `kicad/EbyteBreakout.kicad_sym`, `kicad/EbyteBreakout.pretty/`: project symbol and footprint libraries
  (footprints drawn from the EBYTE datasheet mechanical drawings)
- `kicad/ebyte_e07_e01_breakout_gerbers.zip`: Gerber X2 + Excellon drill, ready for JLCPCB / PCBWay (no drill map files: fabs can mistake those for extra copper layers)
- `kicad/front.png`, `back.png`, `schematic.png`: previews
- `gen/`: the Python scripts that generated the design (edit `design.py` and rerun `run_all.sh` + `build_sch.py`)

## Fab notes

2 layer, 1.6 mm, any finish. Minimums used: 0.2 mm clearance, 0.3 mm tracks, 0.5/0.3 mm vias,
0.12 mm silkscreen. Order 1.0 mm or 1.2 mm thickness if you want the stamp-hole fillets to
sit lower, it makes no difference electrically.

DRC: 0 violations, 0 unconnected. Schematic netlist verified against the PCB pad nets.
